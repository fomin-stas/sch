<?
$MESS ['T_IBLOCK_DESC_LIST'] = "Today works";
$MESS ['T_IBLOCK_DESC_LIST_DESC'] = "The list of employees engaged in receiving today";
$MESS ['T_IBLOCK_DESC_NEWS'] = "list of employees";
?>
