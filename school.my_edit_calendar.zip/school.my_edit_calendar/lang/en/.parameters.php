<?
$MESS["T_IBLOCK_DESC_ASC"] = "Ascending";
$MESS["T_IBLOCK_DESC_DESC"] = "Descending";
$MESS["T_IBLOCK_DESC_FID"] = "ID";
$MESS["T_IBLOCK_DESC_FNAME"] = "Name";
$MESS["T_IBLOCK_DESC_FACT"] = "Activation date";
$MESS["T_IBLOCK_DESC_FSORT"] = "Sorting";
$MESS["T_IBLOCK_DESC_FTSAMP"] = "Date of last change";
$MESS["T_IBLOCK_DESC_LIST_ID"] = "Information block code of schedules";
$MESS["T_IBLOCK_DESC_LIST_TYPE"] = "Type of information block (used for verification only)";
$MESS["T_IBLOCK_DESC_LIST_CONT"] = "News per page";
$MESS["T_IBLOCK_DESC_DETAIL_PAGE_URL"] = "URL for persoonal page";
$MESS["T_IBLOCK_DESC_PAGER_NEWS"] = "employee";
$MESS["STRUCTURE_LINK"] = "Structure page link";
$MESS["STRUCTURE_FILTER"] = "Filter name company structure page";

?>