<?
$MESS['W_C_TEST'] = 'проба проба';
$MESS['T_COPY_FROM'] = 'копировать неделю';
$MESS['T_COPY_TO'] = 'на неделю';

$MESS['T_COPY'] = 'Копировать';
$MESS['T_CLOSE']='Закрыть';

$MESS['PERIOD_EDIT'] = 'Изменить';
$MESS['CALENDAR_MONTH_1'] = 'Января';
$MESS['CALENDAR_MONTH_2'] = 'Февраля';
$MESS['CALENDAR_MONTH_3'] = 'Марта';
$MESS['CALENDAR_MONTH_4'] = 'Апреля';
$MESS['CALENDAR_MONTH_5'] = 'Мая';
$MESS['CALENDAR_MONTH_6'] = 'Июня';
$MESS['CALENDAR_MONTH_7'] = 'Июля';
$MESS['CALENDAR_MONTH_8'] = 'Августа';
$MESS['CALENDAR_MONTH_9'] = 'Сентября';
$MESS['CALENDAR_MONTH_10'] = 'Октября';
$MESS['CALENDAR_MONTH_11'] = 'Ноября';
$MESS['CALENDAR_MONTH_12'] = 'Декабря';

$MESS['T_ALL_WEEKS'] = 'На каждую неделю';
$MESS['T_N_ALL_WEEKS'] = 'Через неделю';
$MESS['T_COUNT'] = 'Раз';
$MESS['T_REPEAT'] = 'Повторить';
?>