<?
$MESS ['CALENDAR_HEADER'] = "Расписание занятий";

$MESS['DURATION_FROM'] = ' с ';
$MESS['DURATION_TO'] = ' по ';

/* Calendar step*/
$MESS['TXT_TODAY'] = '<br>сегодня';
$MESS['CALENDAR_PREV_WEEK'] = 'Показать предыдущую неделю';
$MESS['CALENDAR_NEXT_WEEK'] = 'Показать следующую неделю';
$MESS['CALENDAR_MONTH_1'] = 'Января';
$MESS['CALENDAR_MONTH_2'] = 'Февраля';
$MESS['CALENDAR_MONTH_3'] = 'Марта';
$MESS['CALENDAR_MONTH_4'] = 'Апреля';
$MESS['CALENDAR_MONTH_5'] = 'Мая';
$MESS['CALENDAR_MONTH_6'] = 'Июня';
$MESS['CALENDAR_MONTH_7'] = 'Июля';
$MESS['CALENDAR_MONTH_8'] = 'Августа';
$MESS['CALENDAR_MONTH_9'] = 'Сентября';
$MESS['CALENDAR_MONTH_10'] = 'Октября';
$MESS['CALENDAR_MONTH_11'] = 'Ноября';
$MESS['CALENDAR_MONTH_12'] = 'Декабря';
$MESS['CALENDAR_DAY_0'] = 'Вс';
$MESS['CALENDAR_DAY_1'] = 'Пн';
$MESS['CALENDAR_DAY_2'] = 'Вт';
$MESS['CALENDAR_DAY_3'] = 'Ср';
$MESS['CALENDAR_DAY_4'] = 'Чт';
$MESS['CALENDAR_DAY_5'] = 'Пт';
$MESS['CALENDAR_DAY_6'] = 'Сб';
$MESS['CALENDAR_DAY_7'] = 'Вс';

$MESS['COPY_WEEK'] = 'Копировать всю неделю';

$MESS['MC_EdCal_Placement'] = 'Кабинет:';
$MESS['MC_EdCal_Check_Employee'] = 'Выберите класс:';


$MESS['T_PARAM_2'] = 'Кабинет:';
$MESS['T_PARAM_3'] = 'Время:';
$MESS['TIME_DDELETE_ALERT'] = 'Вы дейcтвительно хотите удалить данное время?';
$MESS['TIME_CANCL_ALERT'] = 'Вы дейcтвительно хотите отменить данное время?';
$MESS['T_EDIT_ALT'] = 'Управление расписанием';

$MESS['CALENDAR_DAY_FULL_0'] = 'Воскресенье';
$MESS['CALENDAR_DAY_FULL_1'] = 'Понедельник';
$MESS['CALENDAR_DAY_FULL_2'] = 'Вторник';
$MESS['CALENDAR_DAY_FULL_3'] = 'Среда';
$MESS['CALENDAR_DAY_FULL_4'] = 'Четверг';
$MESS['CALENDAR_DAY_FULL_5'] = 'Пятница';
$MESS['CALENDAR_DAY_FULL_6'] = 'Суббота';
$MESS['CALENDAR_DAY_FULL_7'] = 'Воскресенье';
$MESS['EMPL_N_STRUCT'] ='Сотрудники, не привязанные к подразделению';
$MESS['LESSON_TIME_EDIT'] ='Редактировать расписание звонков';
$MESS['LESSON_TYPE_EDIT'] ='Редактировать типы занятий';

$MESS['LESSON_TYPE_LEGEND'] ='Время привязанное к расписанию звонков (не может быть меньше или больше чем одно занятие)';
$MESS['FREE_TYPE_LEGEND'] ='Время не привязанное к расписанию звонков (может быть дольше чем одно занятие)';
$MESS['CANCLED_TYPE_LEGEND'] ='Занятие отменено';
$MESS['CALENDAR_YEAR_S'] = ' г.';
?>