<?
$MESS['TEST'] = 'проба проба';
$MESS['PERIOD_EDIT'] = 'Изменить';
?>