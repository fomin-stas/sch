<?
$MESS['T_NO_TEMPLATE_NAME'] = 'Не указано название ';

$MESS['T_TIME_FORMAT_END'] = 'Не верный формат времени конца занятия в строке ';

$MESS['T_TIME_FORMAT_START'] = 'Не верный формат времени начала занятия в строке ';

$MESS['T_NO_TEMPLATE_TIMES'] = 'Не указано ни одного занятия ';

$MESS['T_TIME_START_END1'] = 'Время окончания занятия в строке ';

$MESS['T_TIME_START_END2'] = ' меньше времени начала ';

$MESS['T_TIME_INTERSECT'] = 'пересечение временных интервалов в строках ';

$MESS['T_TIME_AND'] = 'и ';

$MESS['T_LESSON_MISSED'] = 'Пропущен один из уроков ';
?>