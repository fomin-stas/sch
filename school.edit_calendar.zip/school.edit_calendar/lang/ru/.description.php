<?
$MESS ['T_IBLOCK_DESC_LIST'] = "Школьное расписание";
$MESS ['T_IBLOCK_DESC_LIST_DESC'] = "Компонент выводит таблицу с расписанием уроков";
$MESS ['T_IBLOCK_DESC_NEWS'] = "Школьное расписание";
?>