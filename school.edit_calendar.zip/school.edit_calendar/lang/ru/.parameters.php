<? 
$MESS["T_IBLOCK_DESC_ASC"] = "По возрастанию";
$MESS["T_IBLOCK_DESC_DESC"] = "По убыванию";
$MESS["T_IBLOCK_DESC_FID"] = "ID";
$MESS["T_IBLOCK_DESC_FNAME"] = "Название";
$MESS["T_IBLOCK_DESC_FACT"] = "Дата начала активности";
$MESS["T_IBLOCK_DESC_FSORT"] = "Сортировка";
$MESS["T_IBLOCK_DESC_FTSAMP"] = "Дата последнего изменения";
$MESS["T_IBLOCK_DESC_LIST_CONT"] = "Количество сотрудников на странице";
$MESS["T_IBLOCK_DESC_DETAIL_PAGE_URL"] = "URL страницы сотрудника";
$MESS["T_IBLOCK_DESC_PAGER_NEWS"] = "Сотрудники";
$MESS["STRUCTURE_LINK"] = "Страница структуры организации";
$MESS["STRUCTURE_FILTER"] = "Имя фильтра страницы структуры компании";


$MESS["T_IBLOCK_DESC_LIST_ID"] = "Код информационного блока предметов";
$MESS["T_IBLOCK_DESC_LIST_TYPE"] = "Группа пользователей с возможностью редактировать расписание";
$MESS['LESSON_COUNT'] = 'Колличество уроков в дне';
$MESS['DAY_END'] = 'Конец рабочего дня';
$MESS['WEB_STEP'] = 'Шаг сетки календаря (в минутах)';

$MESS['SHOW_BUSY'] = 'Показывать занятость времени';

?>